const modapk = () => { 
	return `
	
🎁𝐏𝐑𝐄𝐒𝐄𝐍𝐓𝐄 𝐏𝐑𝐀 𝐕𝐂𝐒

🔥𝐀𝐏𝐏 𝐏𝐑𝐀 𝐃𝐄𝐒𝐀𝐓𝐈𝐕𝐀𝐑 𝐍𝐔́𝐌𝐄𝐑𝐎 :

https://download2164.mediafire.com/nj6c3facwccg/2hph9lu9hzw3zs u/App+de+desativar+n%C3%BAmeros.apk

🔥𝐓𝐄𝐗𝐓𝐍𝐎𝐖:

https://download1899.mediafire.com/qsiuo7dlp6lg/003igqr7sqt2dcf/TextNow-20.42.0.2.apk

🔥𝐇𝐀𝐏𝐏𝐘𝐌𝐎𝐃:

https://download1211.mediafire.com/voskes20ufeg/17oto9zo7y8tw4i/happymod-2-6-0.apk

🔥𝐒𝐏𝐎𝐓𝐈𝐅𝐘 𝐏𝐑𝐎 :

https://download2224.mediafire.com/8m2hyaop5okg/jsash98c0uvx2ag/Spotify+Pro.apk

🔥𝐖𝐇𝐀𝐓𝐒 𝐏𝐑𝐀 𝐏𝐄𝐃𝐈𝐑 𝐂𝐎́𝐃𝐈𝐆𝐎 𝐐𝐔𝐈𝐍𝐀𝐑𝐈𝐎 :

https://www.mediafire.com/download/ots92ur1a9hivhl

🔥𝐏𝐈𝐂𝐒-𝐀𝐑𝐓 𝐏𝐑𝐎:

https://www.mediafire.com/file/ia6ic0lg399nd7x/PicsArt__Let%25C3%25ADcia_Edits_%2528%2540letici.y%2529_.apk/file

🔥𝐓𝐈𝐑𝐀𝐑 𝐃𝐎 𝐒𝐔𝐏𝐎𝐑𝐓𝐄 -𝟏 :

https://download1779.mediafire.com/ix07s5ftpbag/42tz60ao03rdnqr/TIRAR+DO+SUPORTE-1.txt

🔥𝐀𝐏𝐊 𝐄𝐃𝐈𝐓𝐎𝐑 𝐏𝐑𝐎 :

https://download698.mediafire.com/jp4hqocnbp4g/9gt7ul07dwt4aa6/APK+Editor+Pro.apk

🔥𝐈𝐍𝐒𝐓𝐀𝐆𝐑𝐀𝐌 𝐏𝐑𝐎 :

https://download2331.mediafire.com/7nfxue9xn1pg/9g1psig6jt6wu4x/InstaPro_v7.45-InstaMod.net.apk

 🔥𝐏𝐎𝐖𝐄𝐑𝐃𝐈𝐑𝐄𝐂𝐓𝐎𝐑 𝐏𝐑𝐎//𝐕𝐄𝐑𝐒𝐀̃𝐎 𝟖.𝟎.𝟏 :

https://download2282.mediafire.com/t1ye153o714g/rk4ntbsdalwwc35/com.cyberlink.powerdirector.DRA140225_01-8.0.1-free-www.apksum.com.apk

🔥𝐀𝐔𝐓𝐎 𝐂𝐋𝐈𝐂𝐊𝐄𝐑 :

https://www.mediafire.com/download/k1n4otv7l5vvko7

🔥𝐘𝐎𝐔𝐓𝐔𝐁𝐄 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 :

http://download2044.mediafire.com/gv7wrh8mojlg/9whitdrwcvhd6oc/Youtube+Premium.apk

🔥𝐈𝐍𝐒𝐇𝐎𝐓 𝐏𝐑𝐎 :

https://download2272.mediafire.com/6ldgkbzmi7mg/ux8ak9eigdghslu/inshot+pro+mod.apk

🔥𝐋𝐔𝐂𝐊𝐘 𝐏𝐀𝐓𝐂𝐇𝐄𝐑 :

https://download2347.mediafire.com/gludz4ntgjsg/y6ndoz5hliotj9v/Luckypatcher_9.1.1.apk

🔥𝐒𝐍𝐀𝐏𝐓𝐔𝐁𝐄 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 :

https://www.mediafire.com/file/im2tfwr429jtkhu/Snaptube-VIP-v5.05.0.5057610_build_5057610-arm_androidtunado.com.apk/file?

🔥𝐄𝐒 𝐅𝐈𝐋𝐄 𝐄𝐗𝐏𝐋𝐎𝐑𝐀𝐓𝐎𝐑 𝐏𝐑𝐄𝐌𝐈𝐔𝐌:

http://www.mediafire.com/file/wr73h06pmjdqkgb/ES_File_Explorer_Premium_v4.2.2.7.3_%25281%2529.apk/file

 🔥𝐒𝐏𝐎𝐓𝐈𝐅𝐘 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 :

http://www.mediafire.com/file/kfjq1odyc0r1px8/@lkmodsrepository+Spotify_v8.5.87.921+[Premium].apk/file

🔥𝐂𝐀𝐍𝐕𝐀 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 :

http://www.mediafire.com/file/g32zgbkrf2j0a4j/@lkmodsrepository+Canva+v2.87.0+(Pro).apk/file

🔥RESSO PREMIUM :

http://www.mediafire.com/file/26z83rxh1jyry52/@lkmodsrepository+Resso+v1.22.0+(Premium).apk/file


≪━─━─━━─━≫



🎵PLAY DE MUSICAS🎵

Spotify premium https://www.mediafire.com/file/r46qm088ni0zer6/Spotify_v8.5.89.901_AndroidFinal.com_.apk/file

Resso premium https://www.mediafire.com/file/448srd15t0ej5h0/Resso_MOD_By_ADDA.apk/file

Deezer premium https://www.mediafire.com/file/0l02xmxep50mrvp/Deezer-Premium-6.2.14.116-HACKSBRASIL.apk/file

Youtube vanced https://vancedapp.com/

Snaptube VIP https://www.mediafire.com/file/7yzai262yzow6tf/Snaptube%20VIP%20v5.12.1.5120801%20MOD.apk/file
══════ஜ▲ஜ══════
🎮JOGOS🎮

Gta SA https://www.mediafire.com/file/ln6r3kx0ie77r9t/GTA_San_Andreas_2021.zip/file

Minecraft https://www.mediafire.com/file/q2tfnp46yudmmt1/minecraft-1-17-210-51-xbox-servers.apk/file

NBA http://www.mediafire.com/file/0j7be2qf6r2fd1i/NBA-2K20-v96-0-1.apk/file

Bully http://www.mediafire.com/file/n2w1b3fc13jqvbv/Bully%2528apk%252Bobb%2529.zip/file
❋・────━【❆】━────・❋
📸EDITOR DE FOTOS📸 

PicsArt Premium http://www.mediafire.com/file/1zvldsslezyn637/PicsArt_Premium_Gratis.apk/file

Pixellab Mod http://www.mediafire.com/file/pfe8lhc72n11z72/Pixellab+New+Mods+Aditya+Project.zip/file

📸GRAVADORES E EDITORES DE VIDEO📸

Inshot https://www.mediafire.com/file/ux8ak9eigdghslu/inshot_pro_mod.apk/file

KineMaster Premium https://www.mediafire.com/file/iynbbdp9gf63rxs/KineMaster_4.16.4+-+bydortontutoriais.apk/file

Alight Motion http://www.mediafire.com/file/074i63ws106f8km/Alight_Motion_%255BV.3.4.4%255D_By_Hypersos_channel.zip/file
≪━─━─━─━─◈─━─━─━─━≫
📜GERADORES📜

Cpf https://www.4devs.com.br/gerador_de_cpf

Certidões de Nascimento https://www.4devs.com.br/gerador_numero_certidoes

Cnh https://www.4devs.com.br/gerador_de_cnh

Conta Bancaria https://www.4devs.com.br/gerador_conta_bancaria

Rg https://www.4devs.com.br/gerador_de_rg

Veiculos https://www.4devs.com.br/gerador_de_veiculos

Cep https://www.4devs.com.br/gerador_de_cep

Gerador de cc https://www.4devs.com.br/gerador_de_numero_cartao_credito
≪━─━─━─━─◈─━─━─━─━≫
📱Whatsapp📱

Imune primario https://mega.nz/file/ogYCzbCQ#WpPCYCHv1ivEQp6lobYzTssisGd0jzLnnAQ-n4Wl__0

mensagem para desbanir suporte http://www.mediafire.com/file/y939b4v10j53aj2/DESBANIR_DO_SUPORTE.txt/file

Database atualizada https://www.mediafire.com/file/2azv9rs02bpqv55/%25F0%259F%25A5%2587DB_PROFESSOR_MACABRO_V2_%25F0%259F%25A5%2587.zip/file

Banir numero apk http://www.mediafire.com/file/dn1odjvzso8lzdz/%25E2%2582%2584%25E2%2582%2581%25E1%25B7%25A2%25E2%2582%2585%25E1%25B7%25A1%25F0%259F%2598%2588%25E2%2583%259F%25E2%2598%259EREPORT_WHATSAPP_1.0.apk/file 
═══════╠☆╣═══════
👾APLICATIVOS MOD👾

Facebook Mod http://www.mediafire.com/file/0mmkb4fzgn2orwa/Maki_Facebook.By_tulyo_tech.apk/file

Twitter Mod https://www.mediafire.com/file/p7t5qzk2n5gge11/Twitter_Mod_Pro_V3.1.5.7z/file

InstaPro https://www.mediafire.com/file/89mdfbi893jvx49/InstaPro_v7.61_By_SamMods.apk/file

Telegram https://www.mediafire.com/file/ewj06ap8ugwo3nd/Telegraph_Messenger_%2528Graph_Messenger%2529_-vT5.15.0-P7.7-18711-Acehtutorial.zip/file

TikTok http://www.mediafire.com/file/kyzbxs9eduiqxz5/TikTok_v17.2.4_Pro-meljedroid.apk/file

Snapchat http://www.mediafire.com/file/479ystv5qfoszwd/Snapchat_%255BModdude.com%255D.apk/file

DarkFlix https://install.appcenter.ms/users/androidtunado/apps/darkflix/distribution_groups/vfix.16552?

Auto Responder https://drive.google.com/file/d/1d5T8jUH7O6xkkHwinD5F1qzu9QVSphMd/view

Discord Mod https://www.mediafire.com/file/d6i6pkrbl53ra2o/Bluecord_v1.1.apk/file

Ganhar seguidor no insta https://apkpure.com/br/huwigram/com.huwi.gram/download?from=details

Assistir Anime https://install.appcenter.ms/users/androidtunado/apps/animes-play/distribution_groups/v2.01%20dark?
	MINECRAFT
-
https://www.apkdownload.tech/2021/03/minecraft-v11623050-beta-com-xbox.html
-
BULLY 
-
https://www.apkdownload.tech/2021/03/bully-anniversary-edition-2021-obb.html
-
CRUNCHYROLL
-
https://www.apkdownload.tech/2020/12/crunchyroll-premium-v321.html
-
KINEMASTER PRO
-
https://www.apkdownload.tech/2021/03/kinemaster-diamond-2021.html
-
SNAPTUBE
-
https://www.apkdownload.tech/2021/03/snaptube-2021.html
-
• Minecraft (Original)
-
https://www.mediafire.com/file/4hixmktsfkhky91/Minecraft_v1.16.101.01_Terbaru.zip/file
-
Geometry Dash (MOD)
-
http://www.mediafire.com/file/thnoi1wpa5ex2wn/Geometry_Dash_%2528MOD%2529.apk/file
-
KineMaster (PRO)
-
https://www.mediafire.com/download/eshb8rra8eg5xa3
-
KineMaster Diamond (MOD)
-
https://www.mediafire.com/download/9p8wsnwupnq0lun
-
KineMaster Ruby (MOD)
-
https://www.mediafire.com/download/6b2wa08cmtsr8x8
-
Adobe Photoshop (Original)
-
https://www.mediafire.com/download/whfh12tj4zjpedp
-
Alight Motion (PRO)
-
http://www.mediafire.com/file/tpxj2grwf8imp6i/Alight_Motion_V.3.1.4_%2528Mod%2529_By_bilqis_neha.apk/file
-
Avee Player (PRO)
-
https://www.mediafire.com/download/5vkde8d1gcyk33y
-
Pixellab (PRO)
-
https://www.mediafire.com/download/kxj0xyvrkc8w6h0
-
Inshot (PRO)
-
https://www.mediafire.com/download/7qcmrfdy2o1ynxf
-
WavePad (PRO)
-
https://www.mediafire.com/download/oif50qb8ltdoe2x
-
Vimage (PRO)
-
https://www.mediafire.com/download/egjumopr2wl89tl
-
Zeotropic (PRO)
-
https://www.mediafire.com/download/tw9zwj2km2tjsnh

📦TEMPLATE

• Template Mine Imator
http://www.mediafire.com/file/cxa8io0j0i3a0x4/Mine-Imator_%2528Template_Pika_Gamer%2529_Edited.zip/file

• 50 Template Avee Player 1
https://realsht.mobi/teCTj

• 50 Template Avee Player 2
https://realsht.mobi/hhSMc

• Template Quotes Rainbow
https://realsht.mobi/LbmVw

• Template Quotes 1
https://realsht.mobi/GZuvl

• Template Quotes 2
https://realsht.mobi/lFLqm

• Template Quotes 3
https://realsht.mobi/prMyC

• Template Quotes 4
https://realsht.mobi/FyGha

• Template Quotes 5
https://realsht.mobi/LdpNd

• Template Quotes 6
https://realsht.mobi/BdlQe

• Template Quotes 7
https://realsht.mobi/fdZCs

• Template Quotes 8
https://realsht.mobi/YkqIk

• Template Quotes 9
https://realsht.mobi/BcKdr

• Template Quotes 10
https://realsht.mobi/MaZno

• Template Mega Colab
https://realsht.mobi/JinWs

• Template Colab 1
https://realsht.mobi/bocSM

• Template Colab 2
https://realsht.mobi/eJwLd

• Template Colab 3
https://realsht.mobi/tGMxp

• Template Colab 4
https://realsht.mobi/oQtWo

• Template Colab 5
https://realsht.mobi/rbvWQ

• Template Wajah Orang
https://realsht.mobi/tGMxp

• Template Kacamata
https://realsht.mobi/MpoKs

• Template Unix 1
https://realsht.mobi/dfToI

• Template Unix 2
https://realsht.mobi/hRMsq

• Template Partikel
https://realsht.mobi/wOMlc

• Template Pistol
https://realsht.mobi/exXCy

• Template Solo
https://realsht.mobi/MvYbm

〽️FONTES

• Coleção de fontes para citações
https://realsht.mobi/JkmXx

• 800 Font Picsay/Pixelab
https://realsht.mobi/brKhI

• 400 Font Picsay/Pixelab
https://realsht.mobi/gBHyt

• 200 Font Picsay/Pixelab
https://realsht.mobi/iJQbj

• 100 Font Picsay/Pixelab
https://realsht.mobi/hrTdE

DEXP BOT
`
}
exports.modapk = modapk