const help = (prefix) => {
	return `
⊱ ────── {*DexpBot*} ────── ⊰
┃〘* 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂𝐎𝐄𝐒 *〙
╠👑 * DexpBot*
╠👑 *dono guh*
╠👑 *wa.me/+554384028569*
╠👑 *status: ON*
╠👑 **
╠👑 **
╠👑 **
╠👑 *86 comandos obs no menu*
┃
╠──🌹〘 *𝐍𝐎𝐕𝐈𝐃𝐀𝐃𝐄𝐒* 〙🌹──
┃❗𝐌𝐄𝐍𝐔 𝐑𝐄𝐅𝐎𝐑𝐌𝐔𝐋𝐀𝐃𝐎❗
┃❗*comando de ${prefix}imunes atualizado*❗
┃❗*comando de ${prefix}modapk atualizado somente vip*❗
╠────────────────────
┃Ⓢ  *${prefix}dono*
┃Ⓢ  *${prefix}owner*
┃Ⓢ  *${prefix}ajudantes*
┃
╠───〘 *💌𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒💌* 〙──────
┃
┃Ⓢ  *${prefix}figu ou ${prefix}f*
┃❗Utilidade-faz figurinha so marcar a foto
┃Ⓢ  *${prefix}toimg*
┃❗Utilidade-tranforma figurinha em foto dnv
┃Ⓢ  *${prefix}attp*
┃❗Utilidade-figurinha de texto piscando ex .attp 123
┃Ⓢ *${prefix}tts*
┃❗Utilidade-voz do google
┃Ⓢ  *${prefix}ler*
┃❗Utilidade-coloque em uma legenda de foto com texto
┃Ⓢ  *${prefix}dado2*
┃❗Utilidade-mnd uma sticker de dado/jogo do dado
┃Ⓢ  *${prefix}cc*  
┃❗Utilidade-comando para jogar cara ou coroa
┃
╠───〘 *💬𝐆𝐑𝐔𝐏𝐎𝐒💬* 〙───────
┃Ⓢ *${prefix}rr*
┃❗Utilidade roleta russa
┃Ⓢ *${prefix}%gado*
┃❗Utilidade sua % de  gado
┃Ⓢ *${prefix}%gostoso*
┃❗Utilidade sua % de gostoso
┃Ⓢ *${prefix}%feio*
┃❗Utilidade sua % de feio
┃Ⓢ *${prefix}%gay*
┃❗Utilidade sua % de gay
┃Ⓢ *${prefix}antilink [1/0]*
┃❗Utilidade Anti links 
┃Ⓢ  *${prefix}antifake [1/0]*
┃❗Utilidade Anti número fake 
┃Ⓢ *${prefix}antispam [on/off]*
┃❗Utilidade sem spammers
┃Ⓢ *${prefix}pombinhos*
┃❗Utilidade-shippa um casal aleatorio
┃Ⓢ *${prefix}gostosas*
┃❗Utilidade-as gostosas do grupo
┃Ⓢ *${prefix}gadometro*
┃❗Utilidade-diz o quando alguém é gado
┃Ⓢ *${prefix}linkgp*
┃❗Utilidade Link do gp
┃Ⓢ *${prefix}sn*
┃❗Utilidade-responder com sim ou não
┃Ⓢ *${prefix}marcar*
┃❗Utilidade marca todos 
┃Ⓢ *${prefix}marcar2*
┃❗Utilidade marca todos 
┃Ⓢ *${prefix}marcar3*
┃❗Utilidade Marca todos
┃Ⓢ *${prefix}add [@]*
┃❗Utilidade Add membro
┃Ⓢ *${prefix}banir [@]*
┃❗Utilidade Remover membro
┃Ⓢ *${prefix}promover [@]*
┃❗Utilidade Dar adm
┃Ⓢ *${prefix}rebaixar*
┃❗Utilidade Tirar adm
┃Ⓢ *${prefix}admins*
┃❗Utilidade Adms lista
┃Ⓢ *${prefix}bemvindo [1/0]*
┃❗Utilidade Boas vindas 
┃Ⓢ *${prefix}grupoinfo*
┃❗Utilidade Descrição gp
┃Ⓢ * ${prefix}leveling [on/off]*
┃❗Utilidade Sistema de level
┃Ⓢ *${prefix}level*
┃❗Utilidade Seu level
┃Ⓢ *${prefix}setdesc*
┃❗Utilidade Mudar Descrição
┃Ⓢ *${prefix}gay [@]*
┃❗Utilidade analisar pessoa
┃Ⓢ *${prefix}nomegp*
┃❗Utilidade Nome do gp
┃Ⓢ *${prefix}bv*
┃❗Utilidade Boas vinda [áudio]
┃Ⓢ  *${prefix}tchau*
┃❗Utilidade Despedida [áudio]
┃ Ⓢ *${prefix}abraço*
┃❗Utilidade-marque alguem para abraça-lo
┃Ⓢ  *${prefix}bodia*
┃❗Utilidade-audio de bom dia
┃Ⓢ * ${prefix}batarde*
┃❗Utilidade-audio de boa tarde
┃Ⓢ  *${prefix}banoit*
┃❗Utilidade-audio de boa noite
┃
╠───〘 *🎶𝐏𝐋𝐀𝐘𝐒🎶* 〙──────
┃
┃Ⓢ  *${prefix}play*
┃❗Utilidade Baixa música
┃Ⓢ  *${prefix}estourar*
┃❗Utilidade-deixa audio estourado
┃Ⓢ  *${prefix}bass*
┃❗Utilidade-efeito bass para audio
┃Ⓢ *${prefix}fast*
┃❗Utilidade-deixa audio rapido
┃Ⓢ  *${prefix}gemuk*
┃❗Utilidade-deixa audio longo
┃Ⓢ  *${prefix}esquilo*
┃❗Utilidade-voz de esquilo
┃Ⓢ  *${prefix}slow*
┃❗Utilidade-deixa audio lento
┃Ⓢ  *${prefix}nightcore*
┃❗Utilidade-efeito nightcore para audio
┃
╠───〘 *🎲𝐕𝐀𝐑𝐈𝐀𝐃𝐎𝐒🎲* 〙──────
┃
┃Ⓢ  *${prefix}wame*
┃❗Utilidade Seu link
┃Ⓢ  *${prefix}metodos*
┃❗Utilidade-scripts termux
┃Ⓢ  *${prefix}imunes*
┃❗Utilidade-apks de imunes no momento desatualizado
┃Ⓢ  *${prefix}modapk*
┃❗Utilidade-aplicativos de graça
┃Ⓢ  *${prefix}utils*
┃❗Utilidade-varios packs de tudo
┃Ⓢ  *${prefix}pmake*
┃Ⓢ  *${prefix}plaquinha* 
┃❗Utilidade-fazer suas plaquinhas
┃Ⓢ  *${prefix}ajudantes* 
┃❗Utilidade-todos que ajudaram na criação do bot
┃Ⓢ  *${prefix}pack18*
┃❗Utilidade-packs de +18
┃Ⓢ  *${prefix}alugar*
┃❗Utilidade-caso queira por o bot no seu grupo
┃Ⓢ  *${prefix}termuxbot*
┃❗Utilidade-como fazer bots
┃Ⓢ  *${prefix}membrocm*
┃❗Utilidade-desenho not bad
┃Ⓢ  *${prefix}compras*
┃❗Utilidade-caso queira comprar o bot
┃Ⓢ  *${prefix}cassino*
┃❗Utilidade-jogo do cassino
┃Ⓢ  *${prefix}rankgay*
┃❗Utilidade-rank dos mais gays
┃Ⓢ  *${prefix}rankcaco*
┃❗Utilidade-rank dos camaco ksks
┃
╠───〘 *⭐𝐕𝐈𝐏⭐* 〙──────
┃
┃Ⓢ  *${prefix}cassinovip*
┃❗Utilidade-cassino para vips
┃Ⓢ  *${prefix}dado*
┃❗Utilidade-dado adicional vip
┃
╠───〘 *👑𝐃𝐎𝐍𝐎👑* 〙──────
┃
┃Ⓢ  *${prefix}bc*
┃Ⓢ  *${prefix}desligar*
┃Ⓢ  *${prefix}bloquear* [@]
┃Ⓢ  *${prefix}limpar*
┃Ⓢ  *${prefix}desbloquear* [@]
┃Ⓢ  *${prefix}setprefix*
┃Ⓢ  *${prefix}bloqueados*
┃
╠──〘 👾𝐈𝐍𝐓𝐄𝐑𝐀𝐂̧𝐀𝐎 👾〙────
┃
┃   *Mandar a msg sem o prefixo*
┃ *Ⓢ bah*
┃ *Ⓢ oii*
┃ *Ⓢ bv*
┃ *Ⓢ canta*
┃ *Ⓢ grita*
┃ *Ⓢ causs*
┃ *Ⓢ gemidao*
┃ *Ⓢ musica*
┃
╠──✰〘 DEXP BOT 𝐃𝐎𝐌𝐈𝐍𝐀 〙✰──
┃
┃
┃ 
┃  
┃  Copyright © by DexpBot
┃
╰─〘 DexpBot〙──────────────────`
}

exports.help = help
