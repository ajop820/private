const menu2 = (prefix) => { 
	return `                 
╠══✪〘 JOGOS E DIVERSÃO 〙✪══
║
╠➥ *${prefix}rankfeio*
╠➥ *${prefix}rankgado*
╠➥ *${prefix}rankgay*
╠➥ *${prefix}rankcaco*
╠➥ *${prefix}ranklindo*
╠➥ *${prefix}rankcorno*
╠➥ *${prefix}rr*
╠➥ *${prefix}sn*
╠➥ *${prefix}cc*
╠➥ *${prefix}dado*
╠➥ *${prefix}dado2*
╠➥ *${prefix}gostosas*
╠➥ *${prefix}%gay*
╠➥ *${prefix}%feio*
╠➥ *${prefix}%gado*
╠➥ *${prefix}%gostoso*
╠➥ *${prefix}pombinhos*
╠➥ *${prefix}cassinovip*
╠➥ *${prefix}cassino*
╠➥ *${prefix}membrocm*
╠➥ *${prefix}gadometro*
╠➥ *${prefix}dado2*
╠➥ *${prefix}abraço*
╠➥ *${prefix}faustinho*
║
╠══✪〘 IMAGENS 〙✪══
║
╠➸ *${prefix}boanoite*
╠➸ *${prefix}bomdia*
╠➸ *${prefix}boatarde*
╠➸ *${prefix}EM BREVE MAIS
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
╠➸ *${prefix}
║
╠══✪〘 *DEXP BOT* 〙✪══`
}
exports.menu2 = menu2