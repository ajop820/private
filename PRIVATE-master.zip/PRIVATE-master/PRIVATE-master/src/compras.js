const compras = (prefix, sender) => {
	return `

1-iae men contato do criador wa.me/554384028569
2-acesso vip 10.00
3-comprar o bot 20.00
4-para ter o bot editavel 30.00

DEXP DOMINA RESPEITA`

}

exports.compras = compras
