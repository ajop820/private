const utils = (prefix, sender) => {
	return `LISTA DE UTILITÁRIOS

PACK DE FOTOS PARA EDITAR > TRAVAZAP
https://www.mediafire.com/file/2zghw4ln220duma/PACK_DE_FOTOS_TRAVA_ZAP.zip/file

Pack de Wallpapers 
https://encurta.eu/2QJmIsY

EXCLUSIVO Pack de fotos pra fazer plaquinha
https://www.mediafire.com/file/ofsfhtla8atrpmo/pack_plaquinha_%252B18_BY_sombrio.zip/file

Pack de edição basico completinho
https://www.mediafire.com/file/uu05t78t4er55og/PACK+EFEITOS+BY+@SHL+TV%E2%9A%A0%EF%B8%8F%E2%9C%85.zip/file

Pack de fontes bonitas
https://www.mediafire.com/file/bgv8liojstii9qx/PACK_FONTES_ATUALIZADA_START_DZN.zip/file

Pack para edições quase 1 gb
https://www.mediafire.com/file/lae02ex8t23vyfc/MEGA_PACK_STARTDZN_20K.zip/file


DEXP DOMINA VADIAS👑
CASO QUEIRA QUE ALGUM LINK APAREÇA NESSA LISTA MANDE O LINK DE DOWNLOAD PRO CRIADOR


`
}

exports.utils = utils
