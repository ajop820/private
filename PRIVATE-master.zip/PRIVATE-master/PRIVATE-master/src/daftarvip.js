const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Rp. 10 reais> Acessar recursos ViP
-Rp. 30 reais> Recursos VIP + 1 bot editavel pra vc

*SE QUER REGISTAR VIP :*

*Proprietário do BOT :*

_wa.me/554384028569 ou digite *${prefix}owner*_


`
}
exports.daftarvip = daftarvip