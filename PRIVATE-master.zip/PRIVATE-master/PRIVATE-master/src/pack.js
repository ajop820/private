const pack = (prefix) => {
    return `*PACKS:*
    
COMANDO ${prefix}pack18
`
}
exports.pack = pack