const help1 = (prefix) => {

	return `
┣━━━━°❀ ❬ *𝐌𝐞𝐧𝐮1* ❭ ❀°━━━━┓
┃
┣⊱❥ *MENU EM CRIAÇÃO EM BREVE*

════════════════════
*DEXP* 🤗
*Digite dono para mais info*
════════════════════`
}
exports.help1 = help1

