const metodos = (prefix, sender) => {
	return `DEXP METODOS VIP

*${prefix}mt1* Painel Kiny
*${prefix}mt2* Em breve
*${prefix}mt3* Em breve
*${prefix}mt4* Em breve
*${prefix}mt5* Em breve

METODOS AGREGADOS POR DEXP BOT
` 
}

exports.metodos = metodos
