const pack18 = (prefix, sender) => {
	return `PACKZÃO

😈Produzido por DEXP 😈
🔥Wa.me/554384028569🔥
https://photos.app.goo.gl/Jr4Qk1dFSJepPdRc7
-
https://photos.app.goo.gl/gNxLbJHGVzeWY9iS9
-
https://photos.app.goo.gl/TBbkjGGdAVHjPFt5A
-
https://photos.app.goo.gl/phyRpNFLcAtsknfJ7
-
https://photos.app.goo.gl/g685WWL4T7BcZssk8
-
https://photos.app.goo.gl/Tqvfv8yVdp3FaUnX9
-
https://mega.nz/folder/aU1wVTZR#6_P4jZGjUZmHqC5Fu2Y78Q
-
https://suaurl.com/b995e2
-
https://suaurl.com/55eb2f
-
https://suaurl.com/8c135b
-
https://suaurl.com/5e91e0
-
https://suaurl.com/5c699d
-
https://suaurl.com/dbaae7
-
https://suaurl.com/f43f76

https://photos.app.goo.gl/Jr4Qk1dFSJepPdRc7
-
https://photos.app.goo.gl/gNxLbJHGVzeWY9iS9
-
https://photos.app.goo.gl/TBbkjGGdAVHjPFt5A
-
https://photos.app.goo.gl/phyRpNFLcAtsknfJ7
-
https://photos.app.goo.gl/g685WWL4T7BcZssk8
-
https://photos.app.goo.gl/Tqvfv8yVdp3FaUnX9
-
https://mega.nz/folder/aU1wVTZR#6_P4jZGjUZmHqC5Fu2Y78Q
-
https://suaurl.com/b995e2
-
https://suaurl.com/55eb2f
-
https://suaurl.com/8c135b
-
https://suaurl.com/5e91e0
-
https://suaurl.com/5c699d
-
https://suaurl.com/dbaae7
-
https://suaurl.com/f43f76

`
}

exports.pack18 = pack18
