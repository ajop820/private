const imunes = (prefix, sender) => {
	return `LISTA DE IMUNES/TRAVA ZAP EM GERAL

 prim�rios 

fallen angels 
 https://www.mediafire.com/file/7uxfzfhvmxksgu0/Fallen_Angels_-_rajando_por_tm_BY_PEDRIN_TRAVAS_OFC.apk/file

1.9.5  _ privado 
 https://www.mediafire.com/file/y0ogxjvcfvq3nh4/%25F0%2596%25A6%2583_%25F0%259D%259F%258F.%25F0%259D%259F%2597.%25F0%259D%259F%2593_%25EA%25AA%25B6%25F0%259D%2590%258F%25F0%259D%2590%2591%25F0%259D%2590%2588%25F0%259D%2590%2595%25CD%25A2%25F0%259D%2590%2580%25F0%259D%2590%2593%25F0%259D%2590%2584%25EA%25AB%2582_%25EA%25AA%25B6%25F0%259D%2590%2581%25CD%25A2%25F0%259D%2590%2598%25EA%25AB%2582_%25EA%25AA%25B6%25F0%259D%2590%2581%25F0%259D%2590%2584%25CD%25A2%25F0%259D%2590%2592%25F0%259D%2590%2587_%25F0%259D%2590%2596%25F0%259D%2590%2580%25CD%25A2%25F0%259D%2590%2591%25EA%25AB%2582_%25F0%2596%25A6%2583%25F0%259D%2598%25A3%25F0%259D%2598%25BA_%25F0%259D%2598%2593%25F0%259D%2598%2596%25F0%259D%2598%259A%25F0%259D%2598%259B_%25F0%259D%2598%2594%25F0%259D%2598%2593%25F0%259D%2598%2592_%25F0%259D%2598%2596%25F0%259D%2598%259A%25F0%259D%2598%258F%25F0%259D%2598%258F_%25F0%259D%2598%2596%25F0%259D%2598%258D%25F0%259D%2598%258A.apk/file

dragons war - divis�o 
 https://www.mediafire.com/file/wkl6ftnmniih0p7/%25F0%259D%2590%2583%25F0%259D%2590%2591%25CD%25A2%25F0%259D%2590%2580%25F0%259D%2590%2586%25F0%259D%259A%25AF%25CD%25A2%25F0%259D%2590%258D%25F0%259D%2590%2592_%25F0%259D%2590%2596%25CD%25A2%25F0%259D%2590%2580%25F0%259D%2590%2591_-_%25F0%259D%2590%2583.%25F0%259D%2590%2588.%25F0%259D%2590%2595.%25F0%259D%2590%2588.%25F0%259D%2590%2592.%25F0%259D%2590%2588.%25F0%259D%259A%25AF.%25F0%259D%2590%258D_%25E3%2582%25B9_r.apk/file

egypsius final version
 https://www.mediafire.com/file/cy1tsuhrwujth4g/Egypcius_final_version.apk/file

�xxx 
 https://www.mediafire.com/file/mssjhdog1y0m3m5/%25C2%25BFX.X.X_-_BY_BOLADAOYZX.apk/file

celestial  xxx - ygg
 https://www.mediafire.com/file/7jpioxb33ih0dn5/%25F0%259D%2591%25AA%25F0%259D%2591%25AC%25F0%259D%2591%25B3%25F0%259D%2591%25AC%25F0%259D%2591%25BA%25F0%259D%2591%25BB%25F0%259D%2591%25B0%25F0%259D%2591%25A8%25F0%259D%2591%25B3__%25F0%259D%2591%25BF%25F0%259D%2591%25BF%25F0%259D%2591%25BF_-_%25F0%259D%2592%2580%25F0%259D%2591%25AE%25F0%259D%2591%25AE%25F0%259D%2591%25AB%25F0%259D%2591%25B9%25F0%259D%2591%25A8%25F0%259D%2591%25BA%25F0%259D%2591%25B0%25F0%259D%2591%25B3.apk/file

business v4 
 https://www.mediafire.com/file/sep71l9lrp0m0g1/BUSINESS_V4.apk/file

gzkzin - scotzin
 https://www.mediafire.com/file/rg8b4hau4abdi9m/GZKZIN_-_SCOTZINN.apk/file

cxrzin V14
 https://www.mediafire.com/file/186ayr15vanfnae/CXRZIN_V14.apk/file

murian v3
 https://www.mediafire.com/file/00h3whhyz138c9g/Murian_V3.apk/file

tisu 50k
 https://www.mediafire.com/file/6n3i9s7f98qtnog/TISU_50K.apk/file

x x x -V
 https://www.mediafire.com/file/ne00o2y3pctkjgg/X_X_X_-_V.apk/file

n identificado
 https://www.mediafire.com/file/ijwvdmr3pr5jtia/%25E3%2582%25BD%25E3%2583%25AA%25E3%2583%2586%25E3%2582%25A3%25E3%2582%25A2_r.apk/file

squeezy v2
 https://www.mediafire.com/file/lykefmh5ykn7e9l/SQUEEZE_V2.apk/file

raya
 https://www.mediafire.com/file/t7n81uaazrm8x5q/%25EA%25AA%25B6%25E1%2590%25AC%25F0%259D%2590%2591%25E1%2590%25AC%25F0%259D%2590%2598%25E1%2590%25AC%25F0%259D%2590%2592%25EA%25AB%259D%25F0%259D%2590%2588%25F0%259D%2590%258A%25F0%259D%2590%2588_BY_JOT%25CE%2594xz_MDz.apk/file

dragons war violet
 https://www.mediafire.com/file/wpaqnnen24kz2rq/%25F0%259D%2590%2583%25F0%259D%2590%2591%25F0%259D%259A%25B2%25F0%259D%2590%2586%25F0%259D%259A%25AF%25F0%259D%2590%258D%25F0%259D%2590%2592_%25F0%259D%2590%2596%25F0%259D%259A%25B2%25F0%259D%2590%2591_-_%25F0%259D%2590%2595%25F0%259D%2590%2588%25F0%259D%2590%258E%25F0%259D%2590%258B%25F0%259D%2590%2584%25F0%259D%2590%2593_%25E2%2598%2580%25EF%25B8%258E%25EF%25B8%258E_r%25282%2529.apk/file
 Dady: (2)
 https://www.mediafire.com/file/fj3tlyjhniqtca0/gen_signed%25282%2529.apk/file

overlord 1.0  
 https://www.mediafire.com/file/n0pbl1cifxxe03p/OVERLORD_1.0_BY_Noelzin_%25CF%259E_%25E6%259D%25A5.apk/file

satanic v2 sem absoleto
 https://www.mediafire.com/file/aoo1vqyx1kjcg3a/SAT%25C3%2582NIC_V2_SEM_OBSOLETO-1_%25E2%2598%25A6%25EF%25B8%258E.apk/file

xxx-azul
 https://www.mediafire.com/file/k3vj2re89te5exl/XXX-BLUE.apk/file

ressurection 
 https://www.mediafire.com/file/z9rxdnzyki0yf57/%25F0%259D%2591%2585%25F0%259D%259B%25B4%25F0%259D%2591%2586%25F0%259D%2591%2588%25F0%259D%2591%2585%25F0%259D%2591%2585%25F0%259D%259B%25B4%25F0%259D%2590%25B6%25F0%259D%2591%2587%25F0%259D%2590%25BC%25F0%259D%2591%2582%25F0%259D%2591%2581_BY_PEDRIN_TRAVAS_OFC.apk/file

zap ios
 https://www.mediafire.com/file/vxjan5yepecjwkt/%25F0%259D%2590%2596%25F0%259D%2590%25A1%25F0%259D%2590%259A%25F0%259D%2590%25AD%25F0%259D%2590%25AC%25F0%259D%2590%259A%25F0%259D%2590%25A9%25F0%259D%2590%25A9_%25F0%259D%2590%2588%25F0%259D%2590%258E%25F0%259D%2590%2592_sign.apk/file


secundarios

eternity ( secund�rio )
 https://www.mediafire.com/file/f3pc0liuvg1sqbr/Eternity%2528Secund%25C3%25A1rio%2529.apk/file

5k - black ( secund�rio )
 https://www.mediafire.com/file/0kge1klqtrvpk0h/5K_-_BLACK.apk/file

rizer speed - [][]
 https://www.mediafire.com/file/8to9ek2wptpo5xi/%25F0%259D%2590%2591%25F0%259D%2590%2588%25F0%259D%2590%2599%25F0%259D%2590%2584%25F0%259D%2590%2591_%25F0%259D%2590%2592%25F0%259D%2590%258F%25F0%259D%2590%2584%25F0%259D%2590%2584%25F0%259D%2590%2583_-_%25EF%259D%25A2%25EF%259D%25B3%2528the_final%2529.apk/file

xboss devil
 https://www.mediafire.com/file/05e9f3djyz4tq4t/%25F0%259D%2590%2597%25F0%259D%259A%25A9%25F0%259D%2590%258E%25F0%259D%2590%2592%25F0%259D%2590%2592_%25F0%259D%2590%2583%25F0%259D%259C%25AE%25F0%259D%2590%2595%25F0%259D%2590%2588%25F0%259D%2590%258B.apk/file

 aps banir numero 

defuse v1.1 
 https://www.mediafire.com/file/2wuj20t2ij238p7/base.apk/file

d.f.w
 https://www.mediafire.com/file/fikbvlc1e48i1la/D.F.W.zip/file

hs hacker 
 https://www.mediafire.com/file/9zkfxa6p2ix47mo/HS_HACKER_v1.6x_1.6.apk/file

bonus

picsart
 https://apkadmin.com/mmfn0qv0726p/PicsArt_Gold_Full_v17.1.4.apk.html

minez�ooo
 https://www.mediafire.com/file/u38ih7y7kzmip61/Minecraft_PE_V1.17.10.20_EmzeetGaming.7z/file

 BASE PRA WHATSAPP PRIMARIO

https://www.mediafire.com/file/u1foa3483cbf2z1/gen_signed.apk/file


 WHATSAPP CHELSEA (PRIMARIO)

https://www.mediafire.com/file/bhjyfwi4e6kxp3f/CHELSEA_%25F0%2596%25A1%25B6.apk/file


 YGGBRASIL TUNNADO (PRIMARIO)

https://www.mediafire.com/file/iqgdxl7x7194sq5/%25F0%259D%2590%2597%25F0%259D%2590%2597%25F0%259D%2590%2597_-_%25F0%259D%2590%2598%25F0%259D%2590%2586%25F0%259D%2590%2586%25F0%259D%2590%2583%25F0%259D%2590%2591%25F0%259D%2590%2580%25F0%259D%2590%2592%25F0%259D%2590%2588%25F0%259D%2590%258B_%25F0%2596%25A3%2582_%25E1%25B5%2587%25CA%25B8%25F0%259D%2591%2589%25F0%259D%2591%2587%25F0%259D%2591%258B_%25F0%259D%2591%259A%25F0%259D%2591%259C%25F0%259D%2591%2591%25F0%259D%2591%2591%25F0%259D%2591%2592%25F0%259D%2591%259F.apk/file


 PERTUBATION VERSION 1 (PRIMARIO)

https://www.mediafire.com/file/9vn6zenj0mti1uz/perturbation_final_version1.apk/file


 INFINETEFEM (PRIMARIO)

https://www.mediafire.com/file/97o9ifrn1ovjw0e/%25E1%259A%25B9%25E1%259A%25BB%25E1%259A%25AA%25E1%259B%258F%25E1%259B%258B%25E1%259A%25AA%25E1%259B%2588%25E1%259B%2588%25E1%259B%2592%25E1%259B%2581%25E1%259B%258A%25E1%259B%2596%25E1%259B%259A%25E1%259B%2596%25E1%259A%25B2%25E1%259B%258F%25E1%259B%2589%25E1%259B%259E%25E1%259B%259F%25E1%259B%258AI%25E1%259B%2597%25E1%259A%25A2%25E1%259A%25BE%25E1%259B%2596%25E1%259A%25B2%25E1%259A%25BA%25E1%259B%2581%25E1%259A%25BE%25E1%259B%2596%25E1%259B%258A_by_selectz_%255BCOM_EMOJI%255D%25282%2529.apk/file


 HYDRA 2.0.2.1 (PRIMARIO)

https://www.mediafire.com/file/zfngz3anodu3j32/HYDRA_2.0.2.1.apk/file


 IMUNE TEMA IOS (PRIMARIO)

https://www.mediafire.com/file/i35t9tlombcesi9/Whats_tema_ios_by_XERZINMAKER_%25F0%259F%2594%25A5%25F0%259F%2598%2588_.apk/file


 ETERNYT (PRIMARIO)

https://www.mediafire.com/file/xqo7g3whge2lq4i/Eternity%2528Prim%25C3%25A1rio%2529.apk/file


 HEAVEN FINAL VERSION (PRIMARIO)

https://www.mediafire.com/file/72mtj154dn6qm7m/heaven_final_version_r.apk/file


 WA IBLIS (SECUNDARIO)

https://www.mediafire.com/file/ncm1o0y93fxxu8v/_%25E3%2580%258E%25E2%259C%25AE%25F0%259D%2590%258D%25F0%259D%2590%25921_%25F0%259D%2590%2596%25F0%259D%2590%2580.%25F0%259D%2590%2588%25F0%259D%2590%2581%25F0%259D%2590%258B%25F0%259D%2590%2588%25F0%259D%2590%2592%25E2%259C%25AE%25E3%2580%258F_.apk/file


 THE ONYLY (SECUNDARIO)

https://www.mediafire.com/file/1ddwviicemrd7rq/The_Only%2527s%2528com.theOnlysWA%2529_SECUND%25C3%2581RIO.apk/file


 RINNEGAN V2 (PRIMARIO)

https://www.mediafire.com/file/t9bx93oeckiz09b/Rinnegan_v3.apk/file


 OB2 WA (SECUNDARIO)

https://www.mediafire.com/file/8h3r7jq7ll0yqeg/%25EA%2599%25B3_%25EA%25A6%25BF%25E2%2583%259F%25DB%259C%25F0%259D%2590%258E%25F0%259D%2590%25812__%25F0%259D%2590%2596%25F0%259D%2590%2580_%25E2%259C%25AF.apk/file



ABAIXO EST�O DESATUALIZADOS

JST PRIVATE 
https://mega.nz/file/sR8GibSC#INpStHFQ9IiCJ2xrP1xCUR3SjAwB0oifzd-lXYhoDr0

Imortal v28
https://seulink.net/nVQm

Imune mt bom n sei o nome
https://seulink.net/lVfC

Tisu v5
https://www.mediafire.com/file/riot8h5zac7qj8a/TISU_V5.apk/file

Pack de imunes+fotos trava zap +secundários+primários
https://mega.nz/file/vgYgQLhJ#T64QPcANThFE-Pcmr2Emf2dC4CBF2TteObtWclP2fDg

Pack de travas 
https://www.mediafire.com/file/i2gpjkz75c2f2g5/%257E%25C2%25A5%25E2%2582%25B1%25E2%2582%25B3%25E2%2582%25AC%25D4%259E_%25C6%2589%25C9%2586_%25E2%2582%25AE%25C9%258C%25E2%2582%25B3%25E2%25A9%2594%25E2%2582%25B3%2524%25E2%259C%2593%257E.zip/file

Imune privado 
https://fir3.net/lRQt

Imune com metodos privados
https://fir3.net/46rUs

 Imune da Valhala OF BAN
https://fir3.net/ZGYG

STORCK V3

https://seulink.net/RTIc7C

SKILLER DOMINA VADIAS👑
CASO QUEIRA QUE SEU IMUNE APAREÇA NESSA LISTA MANDE O LINK DE DOWNLOAD PRO CRIADOR

`
}

exports.imunes = imunes
