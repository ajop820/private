const alugar = () => { 
	return `           
╔══✪〘 ALUGAR 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *ALUGUEL: 10 / GRUPO (MÊS)*
╠➥ *CRIAR: 30 (PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *MERCADO PAGO,PIX, BOLETO,*
╠═══════════════════════════
╠➥ *VANTAGENS*
╠➥ *wa.me/554384028569*
║
╚═〘  DEXP 〙
`
}
exports.alugar = alugar