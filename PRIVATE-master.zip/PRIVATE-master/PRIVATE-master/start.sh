#!bin/bash
while : 
do
    npm start
    sleep 1
done